

const controller = require("./controller.js")
const fastify = require('fastify')({
  logger: false
})

fastify.get('/', (request, reply) => {
  let response = controller.readFile();
  reply.send(response)
})

fastify.post('/addData', async (request, reply) => {
  let response = await controller.addData(request);
  console.log("response",response)
  reply.send(response)
})



fastify.listen(4000, (err, address) => {
  if (err) throw err
  // Server is now listening on ${address}
})