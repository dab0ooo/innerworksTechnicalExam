
import './App.css';


function App() {
 
	
  return (
    <div className="App">
      <header className="App-header">
	
        <p>
          TO DO LIST
        </p>
        <a>
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
