

var fs = require('fs');

let readFile = () => {
	return new Promise((resolve,reject) => {
		
			try {  
 			var data = fs.readFileSync('file.txt', 'utf8');
		 	  resolve(data);
			} catch(e) {
		 	   console.log('Error:', e.stack);
			}
			
	})
}


let addData = (request) => {
	return new Promise( (resolve,reject) => {
		let content = request.body.data
		fs.appendFile('file.txt',"\n" + content, function (err) {
  		if (err) {
    			console.log("Error")
  		} else {
			let file = readFile();
    			resolve(file);
  		}
	})
	
})
}

module.exports = {
	readFile,
	addData 
	
}
